﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

using System.Windows.Input;


namespace Copi_and_Create__File_and_folder_.Pages
{
    /// <summary>
    /// Логика взаимодействия для CopiFilePage.xaml
    /// </summary>
    public partial class CopiFilePage : Page
    {
        public CopiFilePage()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigeteFrame.StartFrame.GoBack();
        }


        private void richFaile_PreviewDragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void richFaile_PreviewDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[]) e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files)
                {
                    richFaile.AppendText(file + "\n");
                }
            }
            e.Handled = true;
        }

        private void btnClearFal_Click(object sender, RoutedEventArgs e)
        {
            richFaile.Document.Blocks.Clear();
        }

        private void btnClearPath_Click(object sender, RoutedEventArgs e)
        {
            richPath.Document.Blocks.Clear();
        }

        private void richPath_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                richPath.Document.Blocks.Clear(); 
                string clipboardText = Clipboard.GetText();
                richPath.AppendText(clipboardText);
            }
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // Получаем пути файлов из RichTextBox
            string[] filePaths = richFaile.Document.Blocks
                .Select(block => new TextRange(block.ContentStart, block.ContentEnd).Text.Trim())
                .Where(text => !string.IsNullOrEmpty(text))
                .ToArray();

            // Получаем базовый путь из TextBox
            string basePath = tbPath.Text.Trim();

            // Получаем названия папок из другого RichTextBox
            string[] folderNames = richPath.Document.Blocks
                .Select(block => new TextRange(block.ContentStart, block.ContentEnd).Text.Trim())
                .Where(text => !string.IsNullOrEmpty(text))
                .ToArray();

            // Копируем файлы
            string destinationPath = "";

            foreach (string filePath in filePaths)
            {
                foreach (string folderName in folderNames)
                {
                    try
                    {
                        string fileName = Path.GetFileName(filePath);
                        destinationPath = Path.Combine(basePath, folderName);
                        string destinationFile = Path.Combine(destinationPath, fileName);

                        // Создаем папку, если она не существует
                        if (!Directory.Exists(destinationPath))
                        {
                            Directory.CreateDirectory(destinationPath);
                        }

                        File.Copy(filePath, destinationFile, true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при копировании файла {filePath} в {destinationPath}: {ex.Message}");
                    }
                }
            }

            MessageBox.Show("Файлы успешно скопированы!");
        
        }
    }
}
