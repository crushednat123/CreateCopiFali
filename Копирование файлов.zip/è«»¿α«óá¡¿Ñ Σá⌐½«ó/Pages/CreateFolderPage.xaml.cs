﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using MessageBox = System.Windows.MessageBox;
namespace Copi_and_Create__File_and_folder_.Pages
{
    /// <summary>
    /// Логика взаимодействия для CreateFolderPage.xaml
    /// </summary>
    public partial class CreateFolderPage : Page
    {
        public static string path = "";
        public static List<string> linesList = new List<string>();
        public CreateFolderPage()
        {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string message = "";
            if (path == "")
            {
                MessageBox.Show("Не выбрали где создавать папку(и)");
                return;
            }
            else
            {
                if (radioButtonOne.IsChecked == true)
                {
                    message = "Будет создана одна папка. Вы уверены?";
                }
                else if (radioButtonMultiple.IsChecked == true)
                {
                    message = "Будет создано несколько папок. Вы уверены?";
                 
                }
                else
                {
                    MessageBox.Show("Ничего не выбрано");
                    return;
                }
                MessageBoxResult result = MessageBox.Show(message, "Подтверждение", MessageBoxButton.OKCancel);
                if (result == MessageBoxResult.OK)
                {
                    if (radioButtonOne.IsChecked == true)
                    {
                        if (myTextBox.Text.Length == 0)
                        {
                            MessageBox.Show($"Название папки напишите");
                            return;
                        }
                        else
                        {
                            try
                            {
                                Directory.CreateDirectory(Path.Combine(path, myTextBox.Text));
                                MessageBox.Show($"Папка {myTextBox.Text} создана");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка при создании папки: {ex.Message}");
                            }
                        }
                    }
                    else if (radioButtonMultiple.IsChecked == true)
                    {
                        TextRange textRange = new TextRange(richText.Document.ContentStart, richText.Document.ContentEnd);
                        if (!string.IsNullOrWhiteSpace(textRange.Text))
                        {
                            string richText = textRange.Text;
                            linesList.AddRange(richText.Split(new[] { Environment.NewLine }, StringSplitOptions.None));

                            foreach (string folderName in linesList)
                            {                             
                                if (!string.IsNullOrWhiteSpace(folderName))
                                {
                                   
                                    string newFolderPath = Path.Combine(path, folderName);
                               
                                    try
                                    {
                                        Directory.CreateDirectory(newFolderPath);
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show($"Ошибка при создании папки {folderName}: {ex.Message}");
                                    }
                                }
                            }

                            MessageBox.Show("Папки созданы");
                        }
                        else
                        {
                            MessageBox.Show("Вставьте папки");
                            return;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Действие отменено");
                }
            }
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigeteFrame.StartFrame.GoBack();
        }
        private void myTextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            myTextBox.Focus();
        }
        private void radioButtonOne_Click(object sender, RoutedEventArgs e)
        {
            if (radioButtonOne.IsChecked == true)
            {
                stackNameFolder.Visibility = Visibility.Visible;
                stackList.Visibility = Visibility.Collapsed;
            }
            else if (radioButtonMultiple.IsChecked == true)
            {
                stackNameFolder.Visibility = Visibility.Collapsed;
                stackList.Visibility = Visibility.Visible;
            }
        }
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
             richText.Document.Blocks.Clear();
        }
        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            using (var folderBrowserDialog = new FolderBrowserDialog())
            {
                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    string selectedFolderPath = folderBrowserDialog.SelectedPath;

                    // Очищаем прошлый текст
                    tbPah.Document.Blocks.Clear();

                    // Добавляем новый текст
                    tbPah.Document.Blocks.Add(new Paragraph(new Run(selectedFolderPath)));

                    // Получаем текст из RichTextBox
                    TextRange textRange = new TextRange(tbPah.Document.ContentStart, tbPah.Document.ContentEnd);
                    path = textRange.Text.Trim();
                }
            }
        }

    }
}
