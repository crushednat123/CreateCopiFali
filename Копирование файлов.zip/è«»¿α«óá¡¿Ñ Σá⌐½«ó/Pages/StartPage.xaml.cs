﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Copi_and_Create__File_and_folder_.Pages
{
    /// <summary>
    /// Логика взаимодействия для StartPage.xaml
    /// </summary>
    public partial class StartPage : Page
    {
        public StartPage()
        {
            InitializeComponent();
        }

        private void btnCreateFolder_Click(object sender, RoutedEventArgs e)
        {
            NavigeteFrame.StartFrame.Navigate(new CreateFolderPage());
        }

        private void btnCopiFale_Click(object sender, RoutedEventArgs e)
        {
            NavigeteFrame.StartFrame.Navigate(new CopiFilePage());
        }

        private async void btnPdf_Click(object sender, RoutedEventArgs e)
        {
            string url = "https://tools.pdf24.org/ru/all-tools";
            await Task.Run(() => Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            }));
        }
    }
}
