﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Copi_and_Create__File_and_folder_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
