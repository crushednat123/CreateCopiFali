﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Copi_and_Create__File_and_folder_
{
    internal class NavigeteFrame
    {
        public static Frame StartFrame { get; set; }
    }
}
